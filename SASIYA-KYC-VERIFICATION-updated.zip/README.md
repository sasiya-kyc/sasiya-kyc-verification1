# SASIYA KYC VERIFICATION (Static Website)

Premium black + neon-red 3D UI single-page site, ready for **GitHub** and **Netlify**.

## Important (Read-only site)
Visitors **cannot edit** WhatsApp/Telegram or logos. Only you can change them in the code.

## Set your contact links
Open `script.js` and paste your links here:
- `WHATSAPP_LINK = "https://wa.me/94XXXXXXXXX"`
- `TELEGRAM_LINK = "https://t.me/yourusername"`

## Set real logos (optional)
In `script.js` → `LOGO_URLS`, paste direct image links (png/svg/webp/jpg).

## Netlify deploy
### Option A: Drag & Drop
1. Go to https://app.netlify.com/
2. Add new site → Deploy manually
3. Drag & drop the **ZIP** (or the unzipped folder contents).

### Option B: GitHub
1. Upload files to a GitHub repo
2. Netlify → Add new site → Import an existing project → GitHub
3. Build command: (empty)
4. Publish directory: `/`
